package MDArrays_KamaniDamodar_02052025_pd6.src.image;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.*;

public class ImageCVHSRunner {
    private static ImageCVHS imageProcessor;
    private static BufferedImage originalImage;
    private static JLabel processedImageLabel;
    private static JLabel originalImageLabel;
    private static JPanel mainPanel;
    private static int currentBrightness = 0;
    private static float currentAlpha = 1.0f;
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Window");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        
        try {
            originalImage = ImageIO.read(new File("Images/RhinoHTown.jpg"));
            imageProcessor = new ImageCVHS(originalImage);
        } catch (Exception e) {
        
            return;
        }

        
        mainPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
       
        JPanel originalPanel = new JPanel(new BorderLayout());
        originalPanel.setBorder(BorderFactory.createTitledBorder("original"));
        originalImageLabel = new JLabel();
        originalImageLabel.setHorizontalAlignment(JLabel.CENTER);
        originalPanel.add(originalImageLabel, BorderLayout.CENTER);
        

        JPanel brightnessPanel = new JPanel(new BorderLayout());
        brightnessPanel.setBorder(BorderFactory.createTitledBorder("Brightness"));
        processedImageLabel = new JLabel();
        processedImageLabel.setHorizontalAlignment(JLabel.CENTER);
        brightnessPanel.add(processedImageLabel, BorderLayout.CENTER);
        
        JSlider brightnessSlider = new JSlider(JSlider.HORIZONTAL, -100, 100, 0);
        brightnessSlider.setMajorTickSpacing(50);
        brightnessSlider.setPaintTicks(true);
        brightnessSlider.setPaintLabels(true);
        brightnessPanel.add(brightnessSlider, BorderLayout.SOUTH);
        
        
        JPanel alphaPanel = new JPanel(new BorderLayout());
        alphaPanel.setBorder(BorderFactory.createTitledBorder("alpha"));
        JSlider alphaSlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 100);
        alphaSlider.setMajorTickSpacing(50);
        alphaSlider.setPaintTicks(true);
        alphaSlider.setPaintLabels(true);
        alphaPanel.add(alphaSlider, BorderLayout.SOUTH);
        
       
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton transposeBtn = new JButton("A - Transpose");
        JButton verticalBtn = new JButton("B - Vertical Flip");
        JButton horizontalBtn = new JButton("C - Horizontal");
        
        buttonsPanel.add(transposeBtn);
        buttonsPanel.add(verticalBtn);
        buttonsPanel.add(horizontalBtn);
        
        transposeBtn.addActionListener(e -> {
            int[][] transposed = imageProcessor.transpose();
            updateProcessedImage(transposed);
        });
        
        verticalBtn.addActionListener(e -> {
            int[][] flipped = imageProcessor.verticalFlip();
            updateProcessedImage(flipped);
        });
        
        horizontalBtn.addActionListener(e -> {
            int[][] flipped = imageProcessor.horizontalFlip();
            updateProcessedImage(flipped);
        });
        
    
        brightnessSlider.addChangeListener(e -> {
            currentBrightness = brightnessSlider.getValue();
            int[][] brightened = imageProcessor.setBrightness(currentBrightness);
            updateProcessedImage(brightened);
        });
        
        alphaSlider.addChangeListener(e -> {
            currentAlpha = alphaSlider.getValue() / 100.0f;
            updateProcessedImageAlpha();
        });
        
       
        mainPanel.add(originalPanel);
        mainPanel.add(brightnessPanel);
        mainPanel.add(alphaPanel);
        mainPanel.add(buttonsPanel);
        
        frame.add(mainPanel);
        
        updateOriginalImage();
        
        updateProcessedImage(imageProcessor.setBrightness(0));
        
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    
    private static void updateOriginalImage() {
        ImageIcon icon = new ImageIcon(originalImage);
        originalImageLabel.setIcon(icon);
    }
    
    private static void updateProcessedImage(int[][] processedArray) {
        BufferedImage processedImage = imageProcessor.arrayToBufferedImage(processedArray);
        updateProcessedImageWithAlpha(processedImage);
    }
    
    private static void updateProcessedImageAlpha() {
        int[][] current = imageProcessor.setBrightness(currentBrightness);
        BufferedImage processedImage = imageProcessor.arrayToBufferedImage(current);
        updateProcessedImageWithAlpha(processedImage);
    }
    
    private static void updateProcessedImageWithAlpha(BufferedImage img) {
        if (currentAlpha < 1.0f) {
            BufferedImage alphaImage = new BufferedImage(
                img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = alphaImage.createGraphics();
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, currentAlpha));
            g2d.drawImage(img, 0, 0, null);
            g2d.dispose();
            img = alphaImage;
        }
        ImageIcon icon = new ImageIcon(img);
        processedImageLabel.setIcon(icon);
    }
}