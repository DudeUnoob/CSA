package image;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;

public class ImageCVHSRunner {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Image Processing - Damodar Kamani");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(2, 2));
        
        
        
       
        String imageFile1 = "Images/RhinoHTown.jpg";
        BufferedImage bufImage1 = null;
        
   
        String imageFile2 = "Images/Dog101.jpg";
        BufferedImage bufImage2 = null;
        
        try {
            File file1 = new File(imageFile1);
            File file2 = new File(imageFile2);
        
            
            bufImage1 = ImageIO.read(file1);
            bufImage2 = ImageIO.read(file2);
            
            
        } catch (Exception e) {
            System.out.println("Error loading images");
            return;
        }
        
       
        ImageCVHS img1 = new ImageCVHS(bufImage1);
        ImageCVHS img2 = new ImageCVHS(bufImage2);
        
        
        JPanel panel1Original = new JPanel();
        JPanel panel1Processed = new JPanel();
        JPanel panel2Original = new JPanel();
        JPanel panel2Processed = new JPanel();
        
        
        panel1Original.add(new JLabel("RhinoHTown - Original"));
        panel1Processed.add(new JLabel("RhinoHTown - Brightness +50"));
        panel2Original.add(new JLabel("Dog101 - Original"));
        panel2Processed.add(new JLabel("Dog101 - Brightness -30"));
        

        int[][] brightBits1 = img1.setBrightness(50);
        BufferedImage brightImage1 = img1.arrayToBufferedImage(brightBits1);
        
        int[][] brightBits2 = img2.setBrightness(-30);
        BufferedImage brightImage2 = img2.arrayToBufferedImage(brightBits2);
        
        
        Image scaledOrig1 = bufImage1.getScaledInstance(350, 250, Image.SCALE_SMOOTH);
        Image scaledBright1 = brightImage1.getScaledInstance(350, 250, Image.SCALE_SMOOTH);
        Image scaledOrig2 = bufImage2.getScaledInstance(350, 250, Image.SCALE_SMOOTH);
        Image scaledBright2 = brightImage2.getScaledInstance(350, 250, Image.SCALE_SMOOTH);
        
    
        panel1Original.add(new JLabel(new ImageIcon(scaledOrig1)));
        panel1Processed.add(new JLabel(new ImageIcon(scaledBright1)));
        panel2Original.add(new JLabel(new ImageIcon(scaledOrig2)));
        panel2Processed.add(new JLabel(new ImageIcon(scaledBright2)));
        
   
        frame.add(panel1Original);
        frame.add(panel2Original);
        frame.add(panel1Processed);
        frame.add(panel2Processed);
        
        
        frame.setSize(800, 700);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}