package KamaniDamodar_MyGui_120324_pd6.src.window1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Window1Runner {
    public static void main(String[] args) {
        new Window1(550, 150);
    }
} 