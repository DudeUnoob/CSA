package KamaniDamodar_MyGui_120324_pd6.src.window6;

public class Window6Runner {
    public static void main(String[] args) {
        new Window6(300, 400);
    }
}