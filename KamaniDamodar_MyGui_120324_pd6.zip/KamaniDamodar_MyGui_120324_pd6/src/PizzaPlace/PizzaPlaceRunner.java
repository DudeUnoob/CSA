package KamaniDamodar_MyGui_120324_pd6.src.PizzaPlace;

public class PizzaPlaceRunner {
    public static void main(String[] args) {
        new PizzaPlace();
    }
} 