package KamaniDamodar_MyGui_120324_pd6.src.FontSelection;

public class RadioButtonsRunner {
    public static void main(String[] args) {
        new RadioButtons(400, 300);
    }
} 