
package KamaniDamodar_MyGui_120324_pd6.src.PlayerOneGear;

public class PlayerOneGearRunner {
    public static void main(String[] args) {
        new PlayerOneGear();
    }
}