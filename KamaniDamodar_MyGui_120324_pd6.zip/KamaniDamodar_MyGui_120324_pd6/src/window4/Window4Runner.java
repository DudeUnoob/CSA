package KamaniDamodar_MyGui_120324_pd6.src.window4;

public class Window4Runner {
    public static void main(String[] args) {
        new Window4(300, 400);
    }
}