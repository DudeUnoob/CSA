package KamaniDamodar_MyGui_120324_pd6.src.window5;

public class Window5Runner {
    public static void main(String[] args) {
        new Window5(300, 400);
    }
}