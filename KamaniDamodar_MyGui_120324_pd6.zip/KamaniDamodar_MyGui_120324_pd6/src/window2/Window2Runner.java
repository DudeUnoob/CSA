package KamaniDamodar_MyGui_120324_pd6.src.window2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Window2Runner {
    public static void main(String[] args) {
        new Window2(550, 150);
    }
}