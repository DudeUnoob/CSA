package image;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
 

public class ImageCVHSRunner {
    public static void main(String[] args) {
        DrawingPanel pan = new DrawingPanel(1600, 800);
        Graphics gfx = pan.getGraphics();
        

        String[] files = {"src/image/Images/RhinoHTown.jpg", "src/image/Images/Cat101.jpg"};
        
        for (String fil : files) {
            BufferedImage img = null;
            
            try {
                File imageFile = new File(fil);
                if (!imageFile.exists()) {
                    System.out.println("Cannot find image file: " + imageFile.getAbsolutePath());
                    continue;
                }
                img = ImageIO.read(imageFile);
            } catch (Exception err) {
                System.out.println("Error loading image: " + fil);
                err.printStackTrace();
                continue;
            }

            ImageCVHS cvh = new ImageCVHS(img);
            
            int wid = 300;
            int hgt = 300;
            
         
            Image org = img.getScaledInstance(wid, hgt, Image.SCALE_SMOOTH);
            gfx.drawString("Original " + fil.substring(fil.lastIndexOf("/") + 1), 25, 30);
            gfx.drawImage(org, 25, 50, pan);
            
            
            BufferedImage hfl = cvh.arrayToBufferedImage(cvh.horizontalFlip());
            Image hsc = hfl.getScaledInstance(wid, hgt, Image.SCALE_SMOOTH);
            gfx.drawString("Horizontal Flip", 350, 30);
            gfx.drawImage(hsc, 350, 50, pan);
            
       
            BufferedImage vfl = cvh.arrayToBufferedImage(cvh.verticalFlip());
            Image vsc = vfl.getScaledInstance(wid, hgt, Image.SCALE_SMOOTH);
            gfx.drawString("Vertical Flip", 675, 30);
            gfx.drawImage(vsc, 675, 50, pan);
            
            
            BufferedImage trn = cvh.arrayToBufferedImage(cvh.transpose());
            Image tsc = trn.getScaledInstance(wid, hgt, Image.SCALE_SMOOTH);
            gfx.drawString("Transposed", 1000, 30);
            gfx.drawImage(tsc, 1000, 50, pan);
            
         
            gfx.translate(0, 400);
        }

        pan.sleep(100);
    }
}